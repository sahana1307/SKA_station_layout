# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

import utm
with open('layout.txt', 'r') as f:
    with open('layoutSKA.txt','w') as wp:
        for line in f:
            Type = line.split('\t')
            longd = Type[0]
            latd = Type[1]
            latref = -26.64
            longref = 116.670
            [xref, yref, a, b] = utm.from_latlon(latref, longref)
            [x, y, a1, b1] = utm.from_latlon(float(latd), float(longd))
            X = x - xref
            Y = y - yref
            print(X, Y)
            row = str(X) + '\t' + str(Y) + '\n'
            wp.write(row)



# See PyCharm help at https://www.jetbrains.com/help/pycharm/
